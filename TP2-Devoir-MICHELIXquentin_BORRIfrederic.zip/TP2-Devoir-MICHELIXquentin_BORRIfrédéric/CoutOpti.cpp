#include <iostream>
// Inclusion de la librairie Boost
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/graph/reverse_graph.hpp>
#include <boost/graph/graph_utility.hpp>

using namespace std;
using namespace boost;

// MICHELIX QUENTIN – BORRI FREDERIC

struct VertexProperties
{
  string name;
  unsigned id;

  VertexProperties() : name(""), id(0) {}
  VertexProperties(string const &n, unsigned i) : name(n), id(i) {}
};

struct EdgeProperties
{
  unsigned name;
  EdgeProperties() : name(0) {}
  EdgeProperties(unsigned n) : name(n) {}
};

typedef adjacency_list<
    vecS,
    vecS,
    undirectedS, /* non-orienté */
    VertexProperties,
    EdgeProperties>
    Graph;

typedef pair<int, int> iPair;

//permet de représenter le graphe
struct Graphbis
{
  int V, E;
  vector<pair<int, iPair>> edges;

  // Constructeur
  Graphbis(int V, int E)
  {
    this->V = V;
    this->E = E;
  }

  //ajout d'un arc/arête
  void addEdge(int u, int v, int w)
  {
    edges.push_back({w, {u, v}});
  }

  //fonction de kruskal qui permet de trouver l'arbre de recouvrement minimum
  int kruskal();
};

struct DisjointSets
{
  int *parent, *rnk;
  int n;

  DisjointSets(int n)
  {
    // Alloue la mémoire
    this->n = n;
    parent = new int[n + 1];
    rnk = new int[n + 1];

    for (int i = 0; i <= n; i++)
    {
      rnk[i] = 0;

      parent[i] = i;
    }
  }

  int find(int u)
  {
    if (u != parent[u])
      parent[u] = find(parent[u]);
    return parent[u];
  }

  void fusion(int x, int y)
  {
    x = find(x), y = find(y);

    if (rnk[x] > rnk[y])
      parent[y] = x;
    else
      parent[x] = y;

    if (rnk[x] == rnk[y])
      rnk[y]++;
  }
};

//fonction qui va retourner le coût de l'arbre de recouvrement minimum
int Graphbis::kruskal()
{
  int mst_wt = 0;

  // Trier les arêtes
  sort(edges.begin(), edges.end());

  DisjointSets ds(V);

  vector<pair<int, iPair>>::iterator it;
  for (it = edges.begin(); it != edges.end(); it++)
  {
    int u = it->second.first;
    int v = it->second.second;

    int set_u = ds.find(u);
    int set_v = ds.find(v);

    if (set_u != set_v)
    {
      cout << u << " - " << v << endl;
      mst_wt += it->first;
      ds.fusion(set_u, set_v);
    }
  }

  return mst_wt;
}

int main(int, char *[])
{

  string filename = "Tp2.dot";
  ofstream fout(filename.c_str());


  // Définiton des types noeuds et arcs
  typedef graph_traits<Graph>::vertex_descriptor vertex_t;
  typedef graph_traits<Graph>::edge_descriptor edge_t;

  //------------------------INITIALISATION DU GRAPHE-----------------------------------------------
  Graph g;
  //vertex
  vertex_t A = add_vertex(VertexProperties("1", 1), g);
  vertex_t B = add_vertex(VertexProperties("2", 2), g);
  vertex_t C = add_vertex(VertexProperties("3", 3), g);
  vertex_t D = add_vertex(VertexProperties("4", 4), g);
  vertex_t E = add_vertex(VertexProperties("5", 5), g);
  vertex_t F = add_vertex(VertexProperties("6", 6), g);
  vertex_t G = add_vertex(VertexProperties("7", 7), g);
  vertex_t H = add_vertex(VertexProperties("8", 8), g);
  vertex_t I = add_vertex(VertexProperties("9", 9), g);
  vertex_t J = add_vertex(VertexProperties("10", 10), g);
  vertex_t K = add_vertex(VertexProperties("11", 11), g);
  vertex_t L = add_vertex(VertexProperties("12", 12), g);
  vertex_t M = add_vertex(VertexProperties("13", 13), g);
  vertex_t N = add_vertex(VertexProperties("14", 14), g);
  vertex_t O = add_vertex(VertexProperties("15", 15), g);
  vertex_t P = add_vertex(VertexProperties("16", 16), g);
  vertex_t Q = add_vertex(VertexProperties("17", 17), g);
  vertex_t R = add_vertex(VertexProperties("18", 18), g);
  vertex_t S = add_vertex(VertexProperties("19", 19), g);
  vertex_t T = add_vertex(VertexProperties("20", 20), g);
  vertex_t U = add_vertex(VertexProperties("21", 21), g);
  vertex_t V = add_vertex(VertexProperties("22", 22), g);
  vertex_t W = add_vertex(VertexProperties("23", 23), g);
  vertex_t X = add_vertex(VertexProperties("24", 24), g);
  vertex_t Y = add_vertex(VertexProperties("25", 25), g);
  vertex_t Z = add_vertex(VertexProperties("26", 26), g);
  vertex_t Aa = add_vertex(VertexProperties("27", 27), g);
  vertex_t Bb = add_vertex(VertexProperties("28", 28), g);
  vertex_t Cc = add_vertex(VertexProperties("29", 29), g);
  vertex_t Dd = add_vertex(VertexProperties("30", 30), g);
  vertex_t Ee = add_vertex(VertexProperties("31", 31), g);
  vertex_t Ff = add_vertex(VertexProperties("32", 32), g);
  vertex_t Gg = add_vertex(VertexProperties("33", 33), g);
  vertex_t Hh = add_vertex(VertexProperties("34", 34), g);

  const std::string names[] = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
                               "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
                               "Aa", "Bb", "Cc", "Dd", "Ee", "Ff", "Gg", "Hh"};

  //edges
  pair<Graph::edge_descriptor, bool> e1 = add_edge(A, B, 8, g);
  pair<Graph::edge_descriptor, bool> e2 = add_edge(A, C, 13, g);
  pair<Graph::edge_descriptor, bool> e3 = add_edge(A, F, 12, g);
  pair<Graph::edge_descriptor, bool> e4 = add_edge(A, K, 1, g);
  pair<Graph::edge_descriptor, bool> e5 = add_edge(B, C, 10, g);
  pair<Graph::edge_descriptor, bool> e6 = add_edge(B, I, 21, g);
  pair<Graph::edge_descriptor, bool> e7 = add_edge(C, D, 11, g);
  pair<Graph::edge_descriptor, bool> e8 = add_edge(C, G, 13, g);
  pair<Graph::edge_descriptor, bool> e9 = add_edge(C, Ee, 40, g);
  pair<Graph::edge_descriptor, bool> e10 = add_edge(D, E, 4, g);
  pair<Graph::edge_descriptor, bool> e11 = add_edge(D, F, 2, g);
  pair<Graph::edge_descriptor, bool> e12 = add_edge(D, G, 22, g);
  pair<Graph::edge_descriptor, bool> e13 = add_edge(E, C, 4, g);
  pair<Graph::edge_descriptor, bool> e14 = add_edge(F, E, 5, g);
  pair<Graph::edge_descriptor, bool> e15 = add_edge(G, H, 2, g);
  pair<Graph::edge_descriptor, bool> e16 = add_edge(G, I, 8, g);
  pair<Graph::edge_descriptor, bool> e17 = add_edge(H, M, 1, g);
  pair<Graph::edge_descriptor, bool> e18 = add_edge(I, H, 10, g);
  pair<Graph::edge_descriptor, bool> e19 = add_edge(I, J, 9, g);
  pair<Graph::edge_descriptor, bool> e20 = add_edge(J, K, 1, g);
  pair<Graph::edge_descriptor, bool> e21 = add_edge(J, L, 14, g);
  pair<Graph::edge_descriptor, bool> e22 = add_edge(J, M, 2, g);
  pair<Graph::edge_descriptor, bool> e23 = add_edge(K, L, 14, g);
  pair<Graph::edge_descriptor, bool> e24 = add_edge(K, M, 23, g);
  pair<Graph::edge_descriptor, bool> e25 = add_edge(L, M, 7, g);
  pair<Graph::edge_descriptor, bool> e26 = add_edge(M, G, 12, g);
  pair<Graph::edge_descriptor, bool> e27 = add_edge(M, N, 10, g);
  pair<Graph::edge_descriptor, bool> e28 = add_edge(N, G, 8, g);
  pair<Graph::edge_descriptor, bool> e29 = add_edge(N, O, 18, g);
  pair<Graph::edge_descriptor, bool> e30 = add_edge(O, P, 11, g);
  pair<Graph::edge_descriptor, bool> e31 = add_edge(O, Q, 9, g);
  pair<Graph::edge_descriptor, bool> e32 = add_edge(P, V, 9, g);
  pair<Graph::edge_descriptor, bool> e33 = add_edge(P, Dd, 5, g);
  pair<Graph::edge_descriptor, bool> e34 = add_edge(P, Ee, 6, g);
  pair<Graph::edge_descriptor, bool> e35 = add_edge(P, Ff, 13, g);
  pair<Graph::edge_descriptor, bool> e36 = add_edge(P, Gg, 11, g);
  pair<Graph::edge_descriptor, bool> e37 = add_edge(P, Hh, 13, g);
  pair<Graph::edge_descriptor, bool> e38 = add_edge(Q, R, 10, g);
  pair<Graph::edge_descriptor, bool> e39 = add_edge(R, S, 7, g);
  pair<Graph::edge_descriptor, bool> e40 = add_edge(R, W, 7, g);
  pair<Graph::edge_descriptor, bool> e41 = add_edge(S, T, 6, g);
  pair<Graph::edge_descriptor, bool> e42 = add_edge(S, X, 8, g);
  pair<Graph::edge_descriptor, bool> e43 = add_edge(T, U, 9, g);
  pair<Graph::edge_descriptor, bool> e44 = add_edge(U, Y, 2, g);
  pair<Graph::edge_descriptor, bool> e45 = add_edge(V, T, 10, g);
  pair<Graph::edge_descriptor, bool> e46 = add_edge(V, Gg, 7, g);
  pair<Graph::edge_descriptor, bool> e47 = add_edge(W, X, 4, g);
  pair<Graph::edge_descriptor, bool> e48 = add_edge(W, Z, 8, g);
  pair<Graph::edge_descriptor, bool> e49 = add_edge(X, Y, 15, g);
  pair<Graph::edge_descriptor, bool> e50 = add_edge(X, Z, 6, g);
  pair<Graph::edge_descriptor, bool> e51 = add_edge(Y, Aa, 3, g);
  pair<Graph::edge_descriptor, bool> e52 = add_edge(Y, Bb, 4, g);
  pair<Graph::edge_descriptor, bool> e53 = add_edge(Z, Cc, 10, g);
  pair<Graph::edge_descriptor, bool> e54 = add_edge(Aa, Bb, 2, g);
  pair<Graph::edge_descriptor, bool> e55 = add_edge(Bb, Cc, 7, g);
  pair<Graph::edge_descriptor, bool> e56 = add_edge(Dd, Ee, 2, g);
  pair<Graph::edge_descriptor, bool> e57 = add_edge(Dd, Ff, 10, g);
  pair<Graph::edge_descriptor, bool> e58 = add_edge(Ee, Hh, 8, g);
  pair<Graph::edge_descriptor, bool> e59 = add_edge(Ff, Gg, 1, g);

  write_graphviz(fout, g, make_label_writer(get(&VertexProperties::name, g)), make_label_writer(get(&EdgeProperties::name, g)));
  system("dot -Tpng Tp2.dot > Graphe-tp2.png");

  //-------------------GRAPHE DE RECOUVREMENT MINIMAL --------------------------

  int Vertx = 34, Edgs = 59;
  Graphbis gbis(Vertx, Edgs);

  gbis.addEdge(0, 1, 8);
  gbis.addEdge(0, 2, 13);
  gbis.addEdge(0, 5, 12);
  gbis.addEdge(0, 10, 1);
  gbis.addEdge(1, 2, 10);
  gbis.addEdge(1, 8, 21);
  gbis.addEdge(2, 3, 11);
  gbis.addEdge(2, 6, 13);
  gbis.addEdge(2, 30, 40);
  gbis.addEdge(3, 4, 4);
  gbis.addEdge(3, 5, 2);
  gbis.addEdge(3, 6, 22);
  gbis.addEdge(4, 2, 4);
  gbis.addEdge(5, 4, 5);
  gbis.addEdge(6, 7, 2);
  gbis.addEdge(6, 8, 8);
  gbis.addEdge(7, 12, 1);
  gbis.addEdge(8, 7, 10);
  gbis.addEdge(8, 9, 9);
  gbis.addEdge(9, 10, 1);
  gbis.addEdge(9, 11, 14);
  gbis.addEdge(9, 12, 2);
  gbis.addEdge(10, 11, 14);
  gbis.addEdge(10, 12, 23);
  gbis.addEdge(11, 12, 7);
  gbis.addEdge(12, 6, 12);
  gbis.addEdge(12, 13, 10);
  gbis.addEdge(13, 6, 8);
  gbis.addEdge(13, 14, 18);
  gbis.addEdge(14, 15, 11);
  gbis.addEdge(14, 16, 9);
  gbis.addEdge(15, 21, 9);
  gbis.addEdge(15, 29, 5);
  gbis.addEdge(15, 30, 6);
  gbis.addEdge(15, 31, 13);
  gbis.addEdge(15, 32, 11);
  gbis.addEdge(15, 33, 13);
  gbis.addEdge(16, 17, 10);
  gbis.addEdge(17, 18, 7);
  gbis.addEdge(17, 22, 7);
  gbis.addEdge(18, 19, 6);
  gbis.addEdge(18, 23, 8);
  gbis.addEdge(19, 20, 9);
  gbis.addEdge(20, 24, 2);
  gbis.addEdge(21, 19, 10);
  gbis.addEdge(21, 32, 7);
  gbis.addEdge(22, 23, 4);
  gbis.addEdge(22, 25, 8);
  gbis.addEdge(23, 24, 15);
  gbis.addEdge(23, 25, 6);
  gbis.addEdge(24, 26, 3);
  gbis.addEdge(24, 27, 4);
  gbis.addEdge(25, 28, 10);
  gbis.addEdge(26, 27, 2);
  gbis.addEdge(27, 28, 7);
  gbis.addEdge(29, 30, 2);
  gbis.addEdge(29, 31, 10);
  gbis.addEdge(30, 33, 8);
  gbis.addEdge(31, 32, 1);

  int mst_wt = gbis.kruskal();
  
  cout << "calcul du coût minimum : \n"
       << mst_wt << endl;

  return 0;
}
